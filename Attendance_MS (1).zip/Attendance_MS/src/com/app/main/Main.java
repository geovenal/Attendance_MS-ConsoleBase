package com.app.main;

import com.app.temp_view.MainMenuView;

public class Main {

    public static void main(String[] args) {
        MainMenuView mmv = new MainMenuView();
        mmv.printWelcomeMessage();
        //StudentProfileTempView sptv = new StudentProfileTempView();
        //sptv.profileView("1", "12");
        //ProfileTempView ptv = new ProfileTempView();
        //ptv.profileView("8", "10");
        //ClassesTempView ctv = new ClassesTempView();
        //ctv.classesView("8", "10");
        
    }
}
